
package com.example.fragments

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnInicio = findViewById<Button>(R.id.btnInicio)
        val btnPerfil = findViewById<Button>(R.id.btnPerfil)

        if (savedInstanceState == null) {
            supportFragmentManager
                .beginTransaction()
                .replace(
                    R.id.containerFragment,
                    InicioFragment()
                )
                .commit()
        }

        btnInicio.setOnClickListener {
            supportFragmentManager
                .beginTransaction()
                .replace(
                    R.id.containerFragment,
                    InicioFragment()
                )
                .commit()
        }

        btnPerfil.setOnClickListener {
            supportFragmentManager
                .beginTransaction()
                .replace(
                    R.id.containerFragment,
                    PerfilFragment()
                )
                .commit()
        }
    }
}
